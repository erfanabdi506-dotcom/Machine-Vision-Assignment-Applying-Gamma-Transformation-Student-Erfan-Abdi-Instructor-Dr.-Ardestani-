import os
import glob
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt

# ---------- پیدا کردن عکس (کنار همین فایل پایتون) ----------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
matches = glob.glob(os.path.join(BASE_DIR, "photo_30467019698_x*"))
if not matches:
    raise FileNotFoundError(f"عکس در این پوشه پیدا نشد: {BASE_DIR}")
IMAGE_PATH = matches[0]
print("عکس پیدا شد:", IMAGE_PATH)

# ---------- تنظیمات ----------
GAMMAS = [0.04, 0.2, 0.4, 0.67, 1.0, 1.5, 2.5, 5.0, 10.0]
L = 256  # سطوح روشنایی 0 تا 255

# ---------- خواندن عکس و تبدیل به خاکستری ----------
img = Image.open(IMAGE_PATH).convert("L")
r = np.asarray(img, dtype=np.float64) / (L - 1)  # نرمال‌سازی به [0, 1]

# ---------- تبدیل گاما: s = c * r^gamma ----------
def gamma_transform(r, gamma, c=1.0):
    s = np.clip(c * np.power(r, gamma), 0, 1)
    return (s * (L - 1)).astype(np.uint8)

# ---------- نمایش ----------
n = len(GAMMAS) + 1
cols = 4
rows = int(np.ceil(n / cols))
fig, axes = plt.subplots(rows, cols, figsize=(4 * cols, 4 * rows))
axes = np.atleast_1d(axes).ravel()

axes[0].imshow(img, cmap="gray", vmin=0, vmax=255)
axes[0].set_title("اصلی")
axes[0].axis("off")

for i, g in enumerate(GAMMAS, start=1):
    s = gamma_transform(r, g)
    axes[i].imshow(s, cmap="gray", vmin=0, vmax=255)
    axes[i].set_title(f"γ = {g}")
    axes[i].axis("off")
    Image.fromarray(s).save(os.path.join(BASE_DIR, f"gamma_{g}.png"))

for j in range(n, len(axes)):
    axes[j].axis("off")

plt.tight_layout()
plt.savefig(os.path.join(BASE_DIR, "gamma_results.png"), dpi=150)
plt.show()
